Hi!

This is my submission for the UseR 2013 data analysis contest. 

The main document is rasmus_baath_user_13_data_analysis_contest.html which is a report that describes the analysis made with Knitr and R markdown, note that it requires an internet connection for the math expressions to render. For printing out I also attach rasmus_baath_user_13_data_analysis_contest.pdf which is just print out of the html file. The actuall code is in the rasmus_baath_user_13_data_analysis_contest.Rmd file while the rasmus_baath_user_13_data_analysis_contest.R file contains only the code whith the comments stripped away. 

My submission is licensed under a Creative Commons Attribution 3.0 Unported License (http://creativecommons.org/licenses/by/3.0/). That is, do whatever you like with it but please tell where you got it from!

Best regards,
Rasmus Bååth
rasmus.baath@lucs.lu.se